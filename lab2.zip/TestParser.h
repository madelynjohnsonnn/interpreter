//
//  TestParser.hpp
//  lab1
//
//  Created by Maddie Johnson on 10/6/20.
//  Copyright © 2020 Maddie Johnson. All rights reserved.
//

#ifndef TestParser_h
#define TestParser_h

#include <stdio.h>

class TestParser {
public:
    void TestSchemeList();
};


#endif /* TestParser_hpp */
